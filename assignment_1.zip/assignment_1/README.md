# Design Optimisation 2020
This .zip contains excerpts from my design-optimisation GitHub repo. It is available at https://github.com/XDGFX/design-optimisation.
The repo contains all additional files, including data points, extra code, and 3D models, which may be relevant to running code or for full information.

The reports are exported directly from Notion.so and merged.